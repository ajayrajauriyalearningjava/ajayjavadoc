import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import p1.EmployeeInter;

public class ServiceLocator {

	private static ServiceLocator sl = null;

	// Factory methid having singleton logic
	public static ServiceLocator getLocator() {
		if (sl == null)
			sl = new ServiceLocator();

		return sl;
	}// getLocator()

	// method having ServiceLocator Impl logic
	public Object getService(String jobs)// throws Exception 
	{
		//jobs="SALESMAN&CLERK";
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext(
				"ClientCfg.xml");
		EmployeeInter obj = (EmployeeInter) ctx.getBean("gs");
		// obj.getEmpByDept(null);
		//System.out.println("Hello"+obj.getEmpByDept(jobs));
		return obj;

	}// getService()
}// class
