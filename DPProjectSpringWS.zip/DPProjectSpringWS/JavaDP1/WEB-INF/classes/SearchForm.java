//SearchForm.java
import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForm;

public class SearchForm extends ActionForm {
    private String job[];

    public void reset(ActionMapping mapping,HttpServletRequest req)
    {
        job=new String[1];
        job[0]="no item selected";
    }


    public String[] getJob() {
        return job;
    }

    public void setJob(String[] job) {
        this.job = job;
    }
    
}
