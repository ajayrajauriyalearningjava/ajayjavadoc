import java.io.StringReader;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import p1.EmpBean;
import p1.EmployeeInter;

public class BusinessDelegate {

	public ArrayList getResult(String jobs)// throws Exception
	{
		System.out.println("getResult method of BusinessDeligate class");

		ServiceLocator sl = ServiceLocator.getLocator();
		EmployeeInter inter = (EmployeeInter) sl.getService(jobs);
		String str = inter.getEmpByDept(jobs);
		return parseXML(str);
	}

	public ArrayList parseXML(String str) {
		ArrayList alist = new ArrayList();
		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();

			Document doc = dBuilder
					.parse(new InputSource(new StringReader(str)));
			doc.getDocumentElement().normalize();

			NodeList empList = doc.getElementsByTagName("EMPLOYEE");
			System.out.println(empList.getLength());

			for (int i = 0; i < empList.getLength(); i++) {
				EmpBean eb = new EmpBean();
				Node nNode = empList.item(i);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					Element eElement = (Element) nNode;
					eb.setEmpno(Integer.parseInt(eElement
							.getElementsByTagName("empno").item(0)
							.getTextContent()));
					eb.setEname(eElement.getElementsByTagName("empname")
							.item(0).getTextContent());
					eb.setJob(eElement.getElementsByTagName("job").item(0)
							.getTextContent());
					eb.setSal(Float.parseFloat(eElement
							.getElementsByTagName("sal").item(0)
							.getTextContent()));

					alist.add(eb);
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return alist;
	}

	public static void main(String[] args) {
		System.out.println("HI "
				+ new BusinessDelegate().getResult("SALESMAN&CLERK"));
	}
}
