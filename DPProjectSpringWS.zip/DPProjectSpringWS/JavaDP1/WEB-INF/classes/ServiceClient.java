
import org.springframework.context.support.FileSystemXmlApplicationContext;

import p1.EmployeeInter;
public class ServiceClient {
public static void main(String[] args) throws Exception
{
		/*FileSystemXmlApplicationContext ctx=new FileSystemXmlApplicationContext("ClientCfg.xml");
		EmployeeInter obj=(EmployeeInter)ctx.getBean("gs");
		//obj.getEmpByDept(null);
		System.out.println(obj.getEmpByDept("SALESMAN&CLERK"));
		*/
		ServiceLocator serv=new ServiceLocator();
		//serv.getLocator().getService();
}

}
/*
jar files needed(collect from spring3 soft
**************** 
context.jar
beans.jar
core.jar
asm.jar
expression.jar
web.jar
aop.jar

*********Collect separtely

commons-logging.jar(from spring2)
aopalliance-1.0.jar (internet)
*/