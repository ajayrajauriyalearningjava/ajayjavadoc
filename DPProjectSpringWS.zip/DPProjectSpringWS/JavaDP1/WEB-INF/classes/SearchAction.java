//SearchAction.java
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class SearchAction extends Action {

	BusinessDelegate bd;

    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form,
        HttpServletRequest request, HttpServletResponse response)
    throws Exception {
        //read form data
        SearchForm sf = (SearchForm) form;
        String jobs[] = sf.getJob();
        System.out.println("In execute(-,-,-,-):SearchAction");
        System.out.println("before calling B.method");
        String job="";
        for(String str:jobs)
        {
        	job+=str+"&";
        }
        
        job=job.substring(0,job.length()-1);
        
        // call B.method
        //BusinessDelegate bd = new BusinessDelegate();
        ArrayList al = bd.getResult(job);
        System.out.println("after calling B.method");


        // send result to result page as req attribute
        request.setAttribute("result", al);
        //forward control to result page
        return mapping.findForward("success");
    } //execute(-,-,-,-)
} //class