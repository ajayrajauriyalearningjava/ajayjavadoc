package com.durgasoft;
	 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.springframework.stereotype.Service;
@SOAPBinding(style=SOAPBinding.Style.RPC, use=SOAPBinding.Use.LITERAL, parameterStyle=SOAPBinding.ParameterStyle.WRAPPED)
@WebService(serviceName="empWs")
@Service("emp")
public class EmployeeWs implements EmployeeInter {
	
	@WebMethod
	public String getEmpByDept(String depts) {
		
		String dept[]=depts.split("&");
		
		String sqlQuery="SELECT * FROM EMP WHERE JOB IN(";
		
		for(String d:dept)
		{
			sqlQuery+="'"+d+"',";
		}
		sqlQuery=sqlQuery.substring(0,sqlQuery.length()-1);
		sqlQuery+=")";
		EmployeeDAO empDAO=new EmployeeDAO();
		String xmlData=empDAO.getEmpByDept(sqlQuery);
		return sqlQuery;		
		
		
	}
	
	
	
	public static void main(String args[])
	{
		new EmployeeWs().getEmpByDept("SALESMAN&CLERK");
	}
  
}