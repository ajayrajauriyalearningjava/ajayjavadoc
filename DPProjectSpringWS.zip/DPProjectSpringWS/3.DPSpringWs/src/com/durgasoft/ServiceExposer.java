package com.durgasoft;
import org.springframework.context.support.*;
public class ServiceExposer {
	public static void main(String[] args) 
	{
		
		FileSystemXmlApplicationContext ctx=new FileSystemXmlApplicationContext("ServerCfg.xml");
		System.out.println("Service Exposed successfully");
		
	}

}


/* to access wsdl type the following 

http://localhost:2011//empWs?WSDL

*/

//jars needed
/*
org.sf.context.jar,
beans.jar,
core.jar,
commons-logging.jar,-------->collect from spring2
asm.jar,
expression.jar,
web.jar 
*/