package com.durgasoft;

import org.springframework.stereotype.Service;

public interface EmployeeInter {
	//@Service("emp")
	public String getEmpByDept(String depts);

}
