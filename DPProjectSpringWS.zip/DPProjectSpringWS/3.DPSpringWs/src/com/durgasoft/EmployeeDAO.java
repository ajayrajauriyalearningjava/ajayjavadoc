package com.durgasoft;
	 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.springframework.stereotype.Service;

public class EmployeeDAO implements EmployeeInter {
	
	@WebMethod
	public String getEmpByDept(String sqlQuery) 
	{
		System.out.println(sqlQuery);
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
		PreparedStatement pst=con.prepareStatement(sqlQuery);
		
		ResultSet rs=pst.executeQuery();
		
		String xmlData="<EMPLOYEES>\n";
		String data="";
		while(rs.next())
		{
			xmlData+="\n\t<EMPLOYEE>"+
			"\n\t\t<empno>"+rs.getInt(1)+"</empno>"+
			"\n\t\t<empname>"+rs.getString(2)+"</empname>"+
			"\n\t\t<job>"+rs.getString(3)+"</job>" +
			"\n\t\t<sal>"+rs.getFloat(6)+"</sal>"+
			"\n\t</EMPLOYEE>\n";
		}
		xmlData+="</EMPLOYEES>";
		System.out.println(xmlData);
		return xmlData;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "Exception :"+e;
		} 
		
	}
	
	
	
	public static void main(String args[])
	{
		new EmployeeWs().getEmpByDept("SALESMAN&CLERK");
	}
  
}