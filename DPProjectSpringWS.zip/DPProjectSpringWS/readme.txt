1.      Import "3.DPSpringWs" to your eclipse IDE
   Add the following jars to the buildpath of this project
         org.springframework.asm-3.1.0.RC1.jar  
	 org.springframework.beans-3.1.0.RC1.jar  
	 org.springframework.context-3.1.0.RC1.jar  
	 org.springframework.core-3.1.0.RC1.jar  
	 org.springframework.expression-3.1.0.RC1.jar  
	 ojdbc14.jar  
	 commons-logging.jar  
	 org.springframework.web-3.1.0.RC1.jar  

2.Run ServiceExposer.java
  This will expose the the service as webservice.You can get access to wsdl file by typing this url
  http://localhost:2011/empWs?WSDL

3.Now copy JavaDP1 to web-apps folder,and give request 
  http://localhost:2011/JavaDDP1


JavaDP2 project is eclipse version

	